<template>
  <div><h1 class="text-center py-5">게시글 삭제</h1></div>
</template>
<script>
import axios from "axios";

export default {
  created() {
    const params = new URL(document.location).searchParams;
    axios
      .delete(`http://localhost:9999/vue/api/board/${params.get("no")}`)
      .then(response => {
        alert("삭제 완료!! " + response);
        
        this.$router.push("/list");
      })
      .catch((error) => {
        alert("삭제 중 오류 발생!! " + error);
        this.$router.push("/list");
      });
  },
};
</script>
