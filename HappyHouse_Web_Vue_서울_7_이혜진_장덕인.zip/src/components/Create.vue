<template>
  <div>
    <h1 class="text-center py-5">게시글 등록</h1>
    <table class="table table-condensed w-25">
      <tr>
        <th>글쓴이</th>
        <td>
          <input
            type="text"
            id="writer"
            ref="writer"
            placeholder="작성자를 입력해주세요."
            v-model="writer"
          />
        </td>
      </tr>
      <tr>
        <th>제목</th>
        <td>
          <input
            type="text"
            id="title"
            ref="title"
            placeholder="제목을 입력해주세요."
            v-model="title"
          />
        </td>
      </tr>
      <!-- <tr>
          <th>날짜</th>
          <td>
            <input type="date" id="regtime" ref="regtime" v-model="regtime" />
          </td>
        </tr> -->
      <tr>
        <th>내용</th>
        <td colspan="2">
          <textarea
            id="content"
            ref="content"
            cols="30"
            rows="10"
            placeholder="내용을 입력해주세요."
            v-model="content"
          ></textarea>
        </td>
      </tr>
    </table>

    <div class="text-right">
      <button class="btn btn-primary" @click="createHandler">등록</button>
      <button class="btn btn-light" @click="moveHandler">글목록</button>
    </div>
  </div>
</template>
<script>
import axios from "axios";

export default {
  data() {
    return {
      writer: "",
      title: "",
      content: ""
    };
  },
  methods: {
    createHandler: function() {
      let err = true;
      let msg = "";
      !this.writer &&
        ((msg = "작성자를 입력해주세요."),
        (err = false),
        this.$refs.writer.focus());
      err &&
        !this.title &&
        ((msg = "제목을 입력해주세요."),
        (err = false),
        this.$refs.title.focus());
      err &&
        !this.content &&
        ((msg = "내용을 입력해주세요."),
        (err = false),
        this.$refs.content.focus());

      if (!err) alert(msg);
      else {
        // axios를 이용한 server에 등록 요청
        axios
          .post("http://localhost:9999/vue/api/board", {
            content: this.content,
            title: this.title,
            writer: this.writer
          })
          .then((response) => {
            alert("등록 완료!! " + response);
            this.moveHandler();
          })
          .catch(error => {
            alert(error);
          });
      } // else end
    }, // function end
    moveHandler: function() {
      this.$router.push("/list");
    }
  }
};
</script>
