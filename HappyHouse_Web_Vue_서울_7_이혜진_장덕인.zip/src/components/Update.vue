<template>
  <div>
    <h1 class="text-center py-5">게시글 수정</h1>
    <table class="table table-condensed w-25">
      <tr>
        <th>제목</th>
        <td>
          <input
            type="text"
            id="title"
            ref="title"
            placeholder="제목을 입력해주세요."
            v-model="title"
          />
        </td>
      </tr>
      <!-- <tr>
          <th>날짜</th>
          <td>
            <input type="date" id="regtime" ref="regtime" v-model="regtime" />
          </td>
        </tr> -->
      <tr>
        <th>내용</th>
        <td colspan="2">
          <textarea
            id="content"
            ref="content"
            cols="30"
            rows="10"
            placeholder="내용을 입력해주세요."
            v-model="content"
          ></textarea>
        </td>
      </tr>
    </table>

    <div class="text-right">
      <button class="btn btn-primary" @click="updateHandler">등록</button>
      <button class="btn btn-light" @click="moveHandler">글목록</button>
    </div>
  </div>
</template>

<script>
import axios from "axios";

export default {
  data() {
    return {
      no: "",
      regtime: "",
      writer: "",
      title: "",
      content: ""
    };
  },
  methods: {
    updateHandler: function() {
      let err = true;
      let msg = "";
      // 필수요건 검사
      err &&
        !this.title &&
        ((msg = "제목을 입력해주세요."),
        (err = false),
        this.$refs.title.focus());
      err &&
        !this.content &&
        ((msg = "내용을 입력해주세요."),
        (err = false),
        this.$refs.content.focus());

      if (!err) alert(msg);
      else {
        axios
          .put(`http://localhost:9999/vue/api/board/` + this.no, {
            content: this.content,
            no: this.no,
            regtime: this.regtime,
            title: this.title,
            writer: this.writer
          })
          .then( () => {
            alert("수정 완료!! ");
            this.$router.push("/search?no=" + this.no);
          })
          .catch(error => {
            alert("수정 중 오류 발생!! " + error);
            this.$router.push("/search?no=" + this.no);
          });
      } // else end
    }, // function end
    moveHandler: function() {
      //   this.$router.push({ name: "list" });
      this.$router.push("/list");
    }
  }, // methods end
  created() {
    const params = new URL(document.location).searchParams;
    this.no = params.get("no");
    axios
      .get(`http://localhost:9999/vue/api/board/${params.get("no")}`)
      .then(({ data }) => {
        this.no = data.no;
        this.content = data.content;
        this.regtime = data.regtime;
        this.title = data.title;
        this.writer = data.writer;
      })
      .catch(error => {
        // alert("수정할 데이터를 조회하는 중 오류 발생!!");
        alert(error);
        this.$router.push("/search?no=" + params.get("no"));
      }); // axios end
  } // created end
};
</script>
