<template>
  <div>
    <h1 class="text-center py-5">QnA 게시판</h1>
    <div class="text-right">
      <button class="btn btn-primary" @click="movePage">등록</button>
    </div>
    <div v-if="boards.length">
      <div class="text-center">
        <input type="text" v-model="sname" />
        <button class="btn btn-secondary" @click="searchName">검색</button>
      </div>
      <table class="table table-boarded table-condenced">
        <colgroup>
          <col width="10%" />
          <col width="50%" />
          <col width="15%" />
          <col width="25%" />
        </colgroup>
        <tr class="thead-dark">
          <th>No.</th>
          <th>제목</th>
          <th>작성자</th>
          <th>날짜</th>
        </tr>
        <tr v-for="(board, index) in boards" :key="index">
          <td v-text="board.no"></td>
          <td>
            <router-link :to="'search?no=' + board.no">{{
              board.title
            }}</router-link>
          </td>
          <td v-text="board.writer"></td>
          <td v-text="board.regtime"></td>
        </tr>
      </table>
    </div>
    <div v-else>
      <h3 class="text-center">등록된 게시글이 없습니다.</h3>
    </div>
  </div>
</template>
<script>
import axios from "axios";

export default {
  data() {
    return {
      boards: [], // 화면에 실제로 표시할 board
      src: [], // 추출한 board 원본
      sname: "",
    };
  },
  methods: {
    movePage: function() {
      this.$router.push("/create");
    },
    searchName: function() {
      if (this.sname != "") {
        const temp = [];
        for (let board of this.src)
          if (board.writer.includes(this.sname)) temp.push(board);
        this.boards = temp;
      } else {
        this.boards = this.src;
      }
    },
  },
  created() {
    axios
      .get("http://localhost:9999/vue/api/board")
      .then((response) => {
        this.src = response.data;
        this.boards = response.data;
      })
      .catch((error) => {
        alert(error);
      });
  },
};
</script>
