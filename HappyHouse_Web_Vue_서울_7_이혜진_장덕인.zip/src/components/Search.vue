<template>
  <div>
    <h1 class="text-center py-5">Vue를 이용한 게시판</h1>
    <table class="table table-condensed">
      <tr>
        <th>No.</th>
        <td v-text="board.no"></td>
      </tr>
      <tr>
        <th>글쓴이</th>
        <td v-text="board.writer"></td>
      </tr>
      <tr>
        <th>제목</th>
        <td v-text="board.title"></td>
      </tr>
      <tr>
        <th>날짜</th>
        <td v-text="board.regtime"></td>
      </tr>
      <tr>
        <th>내용</th>
        <td colspan="2" v-text="board.content"></td>
      </tr>
    </table>

    <div class="text-right">
      <router-link class="btn btn-dark" to="/list"> 글목록 </router-link>
      <router-link class="btn btn-success" :to="'/update?no=' + board.no">
        수정
      </router-link>
      <router-link class="btn btn-danger" :to="'/delete?no=' + board.no">
        삭제
      </router-link>
    </div>
  </div>
</template>
<script>
import axios from "axios";

export default {
  data() {
    return {
      board: {},
    };
  },
  created() {
    const params = new URL(document.location).searchParams;
    axios
      .get(`http://localhost:9999/vue/api/board/${params.get("no")}`)
      .then(({ data }) => {
        this.board = data;
      })
      .catch((error) => {
        alert(error);
      });
  },
};
</script>
