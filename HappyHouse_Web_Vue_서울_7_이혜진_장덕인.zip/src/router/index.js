import Vue from "vue";
import VueRouter from "vue-router";
import List from "../components/List.vue";
import Search from "../components/Search.vue";
import Create from "../components/Create.vue";
import Update from "../components/Update.vue";
import Delete from "../components/Delete.vue";

Vue.use(VueRouter);

const routes = [
  {
    path: "/list",
    name: "list",
    component: List,
  },
  {
    path: "/search",
    name: "search",
    component: Search,
  },
  {
    path: "/create",
    name: "create",
    component: Create,
  },
  {
    path: "/update",
    name: "update",
    component: Update,
  },
  {
    path: "/delete",
    name: "delete",
    component: Delete,
  }
];

const router = new VueRouter({
  mode: "history",
  base: process.env.BASE_URL,
  routes,
});

export default router;
